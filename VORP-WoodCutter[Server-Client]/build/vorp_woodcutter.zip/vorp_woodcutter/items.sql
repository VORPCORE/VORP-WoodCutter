INSERT INTO `vorp`.`items`(`item`, `label`, `limit`, `can_remove`, `type`, `usable`) VALUES ('wood', 'Wood', 50, 1, 'item_standard', 0);
INSERT INTO `vorp`.`items`(`item`, `label`, `limit`, `can_remove`, `type`, `usable`) VALUES ('wooden_boards', 'Wooden Boards', 25, 1, 'item_standard', 0);
